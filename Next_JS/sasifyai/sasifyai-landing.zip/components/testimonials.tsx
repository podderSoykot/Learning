import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

const testimonials = [
  {
    name: "Darlene Robertson",
    role: "CEO, UpdateAI",
    content:
      "I'd recommend SasifyAI to any SaaS business looking for top-tier AI-powered content generation with exceptional quality, efficiency, and support.",
    avatar: "/placeholder.svg?height=40&width=40",
  },
  {
    name: "Savannah Nguyen",
    role: "Chief Executive Officer",
    content:
      "I'd recommend SasifyAI to any SaaS business looking for top-tier AI-powered content generation with exceptional quality, efficiency, and support.",
    avatar: "/placeholder.svg?height=40&width=40",
  },
  {
    name: "Dianne Russell",
    role: "Front End Developer",
    content:
      "I'd recommend SasifyAI to any SaaS business looking for top-tier AI-powered content generation with exceptional quality, efficiency, and support.",
    avatar: "/placeholder.svg?height=40&width=40",
  },
  {
    name: "Theresa Webb",
    role: "Human Resource Manager",
    content:
      "I'd recommend SasifyAI to any SaaS business looking for top-tier AI-powered content generation with exceptional quality, efficiency, and support.",
    avatar: "/placeholder.svg?height=40&width=40",
  },
  {
    name: "Darrell Steward",
    role: "Assistant Backend Developer",
    content:
      "I'd recommend SasifyAI to any SaaS business looking for top-tier AI-powered content generation with exceptional quality, efficiency, and support.",
    avatar: "/placeholder.svg?height=40&width=40",
  },
  {
    name: "Josh Schachter",
    role: "Finance",
    content:
      "I'd recommend SasifyAI to any SaaS business looking for top-tier AI-powered content generation with exceptional quality, efficiency, and support.",
    avatar: "/placeholder.svg?height=40&width=40",
  },
]

export function Testimonials() {
  return (
    <section className="py-20">
      <div className="container">
        <div className="text-center mb-16">
          <p className="text-sm font-medium text-accent mb-4">SasifyAI Review</p>
          <h2 className="text-3xl font-bold tracking-tight font-sans sm:text-4xl mb-4">
            See What Our Customers Are Saying About SasifyAI!
          </h2>
          <p className="text-muted-foreground font-serif max-w-3xl mx-auto">
            Read real user experiences and discover how SasifyAI is transforming content creation with efficiency,
            quality, and seamless integration.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="border-0 shadow-lg">
              <CardContent className="p-6">
                <p className="text-muted-foreground font-serif mb-6">"{testimonial.content}"</p>
                <div className="flex items-center space-x-3">
                  <Avatar>
                    <AvatarImage src={testimonial.avatar || "/placeholder.svg"} alt={testimonial.name} />
                    <AvatarFallback>
                      {testimonial.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-semibold font-sans">{testimonial.name}</p>
                    <p className="text-sm text-muted-foreground font-serif">{testimonial.role}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <p className="text-muted-foreground font-serif">
            Trusted by individuals and teams at the world's boldest companies
          </p>
        </div>
      </div>
    </section>
  )
}
