import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Zap, Palette, Clock, Target, Search, Link } from "lucide-react"

const features = [
  {
    icon: Zap,
    title: "AI-Powered Writing",
    description: "Create high-quality blog posts, ads, and emails effortlessly with AI-driven precision.",
  },
  {
    icon: Palette,
    title: "Customizable Tone & Style",
    description:
      "Customize tone, style, and format to align perfectly with your brand's unique voice and target audience.",
  },
  {
    icon: Clock,
    title: "Fast & Efficient",
    description:
      "Generate captivating content instantly, overcoming writer's block and saving time for more creativity.",
  },
  {
    icon: Target,
    title: "Multiple Use Cases",
    description: "Versatile content creation From blogs to social media, emails, and more—SasifyAI covers it all.",
  },
  {
    icon: Search,
    title: "SEO-Optimized Content",
    description: "Create SEO-optimized content that improves rankings and attracts more traffic to your website.",
  },
  {
    icon: Link,
    title: "Seamless Integrations",
    description: "Easily connect with CMS, marketing platforms, and more for smooth workflow.",
  },
]

export function FeaturesSection() {
  return (
    <section id="features" className="py-20 bg-muted/30">
      <div className="container">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold tracking-tight font-sans sm:text-4xl">Key Features of SasifyAI</h2>
          <p className="mt-4 text-xl text-muted-foreground font-serif max-w-3xl mx-auto">
            Powerful AI writing tools to supercharge your content creation
          </p>
          <p className="mt-2 text-muted-foreground font-serif max-w-4xl mx-auto">
            Effortlessly generate high-quality, engaging, and SEO-optimized content for blogs, ads, emails, and more—all
            in just a few clicks.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader>
                <div className="flex items-center space-x-3">
                  <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-accent/10">
                    <feature.icon className="h-6 w-6 text-accent" />
                  </div>
                  <CardTitle className="font-sans">{feature.title}</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-base font-serif">{feature.description}</CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
