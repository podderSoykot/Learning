import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { FileText, Sparkles, Edit } from "lucide-react"

const steps = [
  {
    icon: FileText,
    title: "Input Your Requirements",
    description: "Provide a brief prompt, and let our AI understand your content needs instantly.",
  },
  {
    icon: Sparkles,
    title: "AI Generates Content",
    description: "Our AI creates high-quality, relevant content instantly, tailored to you.",
  },
  {
    icon: Edit,
    title: "Customize & Edit",
    description: "Refine, adjust, and perfect your content to align with your brand's voice and style.",
  },
]

export function HowItWorks() {
  return (
    <section className="py-20">
      <div className="container">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold tracking-tight font-sans sm:text-4xl">How SasifyAI Works</h2>
          <p className="mt-4 text-xl text-muted-foreground font-serif max-w-3xl mx-auto">
            Command Our AI to Craft Perfect Copy in Seconds
          </p>
          <p className="mt-2 text-muted-foreground font-serif max-w-4xl mx-auto">
            Effortlessly instruct our AI to generate high-quality, tailored content in seconds, boosting productivity
            and creativity for any project.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {steps.map((step, index) => (
            <div key={index} className="relative">
              <Card className="text-center border-0 shadow-lg">
                <CardHeader>
                  <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-accent/10 mb-4">
                    <step.icon className="h-8 w-8 text-accent" />
                  </div>
                  <CardTitle className="font-sans">{step.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-base font-serif">{step.description}</CardDescription>
                </CardContent>
              </Card>
              {index < steps.length - 1 && (
                <div className="hidden md:block absolute top-1/2 -right-4 w-8 h-0.5 bg-accent/30 transform -translate-y-1/2" />
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
