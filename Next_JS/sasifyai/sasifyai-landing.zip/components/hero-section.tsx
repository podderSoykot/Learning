import { Button } from "@/components/ui/button"
import { Play } from "lucide-react"

export function HeroSection() {
  return (
    <section className="relative py-20 lg:py-32 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-background via-muted/20 to-accent/5" />
      <div className="container relative">
        <div className="mx-auto max-w-4xl text-center">
          <h1 className="text-4xl font-bold tracking-tight font-sans sm:text-6xl lg:text-7xl">
            Boost your <span className="text-accent">productivity</span>
          </h1>
          <p className="mt-6 text-xl text-muted-foreground font-serif max-w-3xl mx-auto">
            Capture the perfect audience pull with SasifyAI! Generate content effortlessly with AI-driven precision,
            whether you need a landing page, blog, or marketing copy for your business.
          </p>
          <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
            <Button size="lg" className="bg-accent hover:bg-accent/90 text-lg px-8 py-6">
              Start Free Trial
            </Button>
            <Button variant="outline" size="lg" className="text-lg px-8 py-6 bg-transparent">
              <Play className="mr-2 h-5 w-5" />
              Watch Demo
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
