import { CheckCircle } from "lucide-react"

const benefits = [
  "AI-Powered Precision – Generate high-quality, engaging, and SEO-optimized content instantly with cutting-edge AI technology.",
  "Customizable Output – Adjust tone, style, and format to match your brand's unique voice effortlessly.",
  "Lightning-Fast Creation – Eliminate writer's block and produce compelling blogs, ads, and emails in seconds.",
  "Seamless Integration – Easily connect with CMS, marketing tools, and workflows for a smooth content experience.",
]

export function WhyChoose() {
  return (
    <section className="py-20 bg-muted/30">
      <div className="container">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl font-bold tracking-tight font-sans sm:text-4xl mb-6">Why Choose SasifyAI?</h2>
            <p className="text-xl text-muted-foreground font-serif mb-8">
              Intelligent AI Solutions to Elevate Your Content Creation Effortlessly
            </p>
            <p className="text-muted-foreground font-serif mb-8">
              SasifyAI revolutionizes content creation with AI-powered precision, generating high-quality, engaging, and
              SEO-optimized copy in seconds. Customize tone, style, and format effortlessly. Say goodbye to writer's
              block and produce compelling blogs, ads, and emails with ease—all in one powerful tool.
            </p>
            <div className="space-y-4">
              {benefits.map((benefit, index) => (
                <div key={index} className="flex items-start space-x-3">
                  <CheckCircle className="h-6 w-6 text-accent flex-shrink-0 mt-0.5" />
                  <p className="text-muted-foreground font-serif">{benefit}</p>
                </div>
              ))}
            </div>
          </div>
          <div className="relative">
            <div className="aspect-square rounded-2xl bg-gradient-to-br from-accent/20 to-accent/5 p-8 flex items-center justify-center">
              <img
                src="/placeholder.svg?height=400&width=400"
                alt="SasifyAI Dashboard"
                className="rounded-lg shadow-2xl"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
